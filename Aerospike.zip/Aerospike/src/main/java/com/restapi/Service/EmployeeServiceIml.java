package com.restapi.Service;

import com.restapi.Model.Employee;
import com.restapi.Repository.EmployeeRepositoryIml;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.List;

@Singleton
public class EmployeeServiceIml implements EmployeeService {
    @Inject
    EmployeeRepositoryIml employeeRepository;
    @Inject
    EmailService emailRepository;
    @Override
    public String addEmployee(Employee employee) {
        return employeeRepository.addEmployee(employee);


    }
    public List<Employee> getAllEmployee(){
        return employeeRepository.getAllEmployee();
    }

    @Override
    public Employee getEmployeeById(int id) {
        return employeeRepository.findById(id);
        //return get
    }

    @Override
    public String updateEmployee(Employee employee, int id) {
        return employeeRepository.updateEmployee(employee, id);
    }
    public String deleteById(int id){
        return employeeRepository.deleteById(id);
    }

}
