package com.restapi.Service;

import com.restapi.Model.Employee;
import jakarta.inject.Singleton;

import java.util.List;

@Singleton
public interface EmployeeService {
    public String addEmployee(Employee employee);
    public List<Employee> getAllEmployee();
    public Employee getEmployeeById(int id);
    public String updateEmployee(Employee employee , int id);
    public String deleteById(int id);

}


